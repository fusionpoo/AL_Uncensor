AL_Uncensor 0.9.1 - uncensor for Amanatsu Location (ILLGAMES)
==============================================================

Uncensors female and male characters: the mosaic genitals are replaced with real geometry
(vulva, anus, penis) ported from DilleDing's Aicomi uncensor hardmod, with a pubic-hair mask,
a glans detail texture and a soft pink tint inside the labia.

Requirements
  * Amanatsu Location (tested with the Steam build running Unity 6000.0.65f1)
  * BepInEx 6 IL2CPP  (tested with 6.0.0-be.788). Run the game once after installing BepInEx
    so it generates BepInEx\interop before installing this mod.

Install
  1. Copy the BepInEx folder from this package into the game folder (merging with the existing one).
     Everything lives in BepInEx\plugins\AL_Uncensor\ :
        AL_Uncensor.dll        the plugin
        body_00.unity3d        modified body bundle, both sexes (served to the game at runtime; no game file is replaced)
        body_00.female.unity3d same but with the vanilla penis, used when "Uncensor males" is off
        cm_dankon_00_det.rg    glans detail mask
        labia_mask.r           pink tint map
  2. Start the game. BepInEx\LogOutput.log should contain "AL Uncensor 0.9.1 loaded" and, once a
     character loads, "redirecting lib/chara/body/body_00.unity3d -> ...".

Config  (BepInEx\config\AL_Uncensor.cfg, created on first run)
  Enabled                               master switch
  Uncensor females / Uncensor males     per sex. Turning "Uncensor males" off gives a female-only
                                        uncensor: the plugin serves body_00.female.unity3d and leaves
                                        the male mosaic exactly as vanilla.
  Show outside H scenes                 also show genitals in the maker / free roam (default on)
  No pubic hair on female genitals      masks the underhair texture below the mons (default on)
  Keep hair above the vulva             keep the mons hair, only remove it from the labia (default on)
  Hair cut line v / Hair fade band      where the mask cuts, in underhair-texture V coordinates
  Vulva pink tint                       0..1, tint inside the slit (default 0.5)
  Penis glans detail / Glans tint strength
  [Hardmod] Load body bundle from plugin folder  the runtime redirect (default on)
  [Hardmod] Body bundle file                     override; empty = pick from the sex switches
  [Experimental] Body _DistanceCutoff override   leave at -1

Notes
  * The game's own lib\chara\body\body_00.unity3d is never modified: the plugin hooks
    AssetBundle.LoadFromFile and hands the game the bundle from the plugin folder instead.
    Game updates or Steam file verification cannot break the install; if a future update ships a
    new body bundle, the plugin keeps serving this one until the mod is updated.
  * Uninstall: delete BepInEx\plugins\AL_Uncensor.
  * If you used an older version that replaced body_00.unity3d, restore your backup of the vanilla
    file (the plugin works either way, but the game file should be vanilla).

Credits
  * DilleDing - the vulva/anus/penis meshes and glans mask come from his Aicomi uncensor hardmod
    (ACUncensorHardmod). Please credit him if you redistribute this, and ask him before
    publishing it widely.
  * Packaging, plugin and mesh port: fusionpoo (with Claude).
